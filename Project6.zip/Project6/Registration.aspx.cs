﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Project6
{
    public partial class Registration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-QOKPV0O;Initial Catalog=Regist;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            lb1.Text = "<b><font color=Brown>" + "WELLCOME:: " + "</font>" + "<b><font color=red>" + Session["UserName"] + "</font>";
            
            DataTable subjects = new DataTable();

            


            //}
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "insert into Registration values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox4.Text + "','" + DropDownList2.Text + "','" + DropDownList1.Text + "','" + TextBox3.Text + "','" + DropDownList3.Text + "')";
            cmd.ExecuteNonQuery();

            con.Close();
        }

       

        protected void Button3_Click(object sender, EventArgs e)
        {
           
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "UPDATE Registration SET Grade = '" + DropDownList7.Text + "' WHERE [StudentId] = '" + DropDownList6.Text + "'";
            cmd.ExecuteNonQuery();

            con.Close();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "select * from Registration";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            DataList1.DataSource = dt;
            DataList1.DataBind();


            con.Close();
        }
    }
}