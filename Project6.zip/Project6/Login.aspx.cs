﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace Project6
{
    public partial class Login : System.Web.UI.Page
    {
        //string strConnString = ConfigurationManager.ConnectionStrings[@"Data Source=DESKTOP-QOKPV0O;Initial Catalog=Regist;Integrated Security=True"].ConnectionString;
        SqlCommand com;
        SqlDataAdapter sqlda;
        string str;
        DataTable dt;
        int RowCount;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            string UserName = TextBox_user_name.Text.Trim();
            string Password = TextBox_password.Text.Trim();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-QOKPV0O;Initial Catalog=Regist;Integrated Security=True");
            con.Open();
            str = "Select * from Login";
            com = new SqlCommand(str);
            sqlda = new SqlDataAdapter(com.CommandText, con);
            dt = new DataTable();
            sqlda.Fill(dt);
            RowCount = dt.Rows.Count;
            for (int i = 0; i < RowCount; i++)
            {
                UserName = dt.Rows[i]["UserName"].ToString();
                Password = dt.Rows[i]["Password"].ToString();
                if (UserName == TextBox_user_name.Text && Password == TextBox_password.Text)
                {
                    Session["UserName"] = UserName;
                    Response.Redirect("Registration.aspx");
                }
                else
                {
                    lb1.Text = "Invalid User Name or Password! Please try again!";
                }
            }
        }

    }

}